<?php $__env->startSection('title', 'Kontrol Lampu'); ?>

<?php $__env->startPush('custom-style'); ?>
    <link href="<?php echo e(asset('css/sb-admin-2.min.css')); ?>" rel="stylesheet">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('devices'); ?>
    <?php if($devices->count() != 0): ?>
        <div class="d-flex flex-grow-1 justify-content-end">
            <select class="custom-select col-md-4" aria-label="Default select example" id="device" name="device"
                onchange="changeDevice();">
                <?php $__currentLoopData = $devices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($item->id); ?>"
                        <?php if(isset($_GET['d'])): ?> <?php if($_GET['d'] == $item->id): ?> selected <?php endif; ?> <?php endif; ?>><?php echo e($item->id); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <button type="button" class="btn btn-primary mx-2" data-toggle="modal" data-target="#staticBackdrop">
                <i class="fas fa-plus"></i>
            </button>

            <!-- Modal -->
            <div class="modal fade" id="staticBackdrop" data-backdrop="static" data-keyboard="false" tabindex="-1"
                aria-labelledby="staticBackdropLabel" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="staticBackdropLabel">Tambahkan ID device</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <form action="/kontrol-lampu" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="modal-body">
                                <input type="text" class="form-control" name="device_id" id="device_id"
                                    placeholder="ex: ID001" maxlength="8" required>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                <button type="submit" class="btn btn-primary">Tambah</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php if($devices->count() == 0): ?>
        <div class="row">
            <div class="col col-xl-12 col-lg-7">
                <div class="card shadow mb-4">
                    <div class="card-header py-3">
                        <h6>Tambahkan device terlebih dahulu</h6>
                    </div>
                    <div class="card-body d-flex justify-content-center">
                        <button type="button" class="btn btn-lg btn-primary" data-toggle="modal"
                            data-target="#staticBackdrop">
                            <i class="fas fa-plus"></i>
                            <span class="mx-2">Tambahkan device</span>
                        </button>

                        <!-- Modal -->
                        <div class="modal fade" id="staticBackdrop" data-backdrop="static" data-keyboard="false"
                            tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="staticBackdropLabel">Masukkan ID device</h5>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <form action="/kontrol-lampu" method="post">
                                        <?php echo csrf_field(); ?>
                                        <div class="modal-body">
                                            <input type="text" class="form-control" name="device_id" id="device_id"
                                                placeholder="ex: ID001" maxlength="8" required>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary"
                                                data-dismiss="modal">Close</button>
                                            <button type="submit" class="btn btn-primary">Tambah</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php else: ?>
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Status Lampu</h6>
            </div>
            <form action="/update-lampu" method="post">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <?php echo e(session('status')); ?>

                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                    <?php endif; ?>
                    <div class="form-group">
                        <label for="mode" class="small mb-1">Mode</label>
                        <div id="mode" class="btn-group btn-group-toggle btn-group-sm mx-4" data-toggle="buttons">
                            <label class="btn btn-outline-primary  <?php if($getLastLampStatus->mode == 0): ?> active <?php endif; ?>">
                                <input type="radio" name="mode" id="otomatis" value="0"
                                    <?php if($getLastLampStatus->mode == 0): ?> checked <?php endif; ?>
                                    autocomplete="off">
                                Otomatis
                            </label>
                            <label class="btn btn-outline-primary <?php if($getLastLampStatus->mode == 1): ?> active <?php endif; ?>">
                                <input type="radio" name="mode" id="manual" value="1"
                                    <?php if($getLastLampStatus->mode == 1): ?> checked <?php endif; ?>
                                    autocomplete="off">
                                Manual
                            </label>
                        </div>
                    </div>
                    <?php if($getLastLampStatus->mode == 0): ?>
                        <div class="row" id='status'>
                            <div class="col-md-4">
                                <div class="small mb-1">Batas suhu untuk lampu mati saat ini</div>
                                <div class="medium mb-1 text-danger">
                                    <strong><?php echo e($getLastLampStatus->suhu_mati ?? 'N/A'); ?></strong>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="small mb-1">Batas suhu untuk lampu menyala saat ini</div>
                                <div class="medium mb-1 text-success">
                                    <strong><?php echo e($getLastLampStatus->suhu_nyala ?? 'N/A'); ?></strong>
                                </div>
                            </div>
                        </div>
                        <div class="row" id="show">
                            <div class="form-group col-md-4">
                                <div class="small mb-1">Batas suhu untuk lampu mati</div>
                                <div class="row justify-content-center align-items-center">
                                    <div class="col-9">
                                        <input type="range" class="custom-range w-100" min="25" max="35"
                                            value="<?php echo e($getLastLampStatus->suhu_mati); ?>" name="suhu_mati" id="suhu_mati"
                                            oninput="document.getElementById('label-suhu-mati').innerHTML = this.value">
                                    </div>
                                    <div class="col-3">
                                        <span class="small mb-1 text-center"
                                            id="label-suhu-mati"><?php echo e($getLastLampStatus->suhu_mati); ?></span>
                                        <span class="small mb-1">°C</span>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group col-md-4">
                                <div class="small mb-1">Batas suhu untuk lampu menyala</div>
                                <div class="row justify-content-center align-items-center">
                                    <div class="col-9">
                                        <input type="range" class="custom-range w-100" min="25" max="35"
                                            value="<?php echo e($getLastLampStatus->suhu_nyala); ?>" name="suhu_nyala"
                                            id="suhu_nyala"
                                            oninput="document.getElementById('label-suhu-nyala').innerHTML = this.value">
                                    </div>
                                    <div class="col-3">
                                        <span class="small mb-1 text-center"
                                            id="label-suhu-nyala"><?php echo e($getLastLampStatus->suhu_nyala); ?></span>
                                        <span class="small mb-1">°C</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php else: ?>
                        <div class="row" id="status">
                            <div class="col-md-4">
                                <div class="small mb-1">Batas jam untuk lampu mati saat ini</div>
                                <div class="medium mb-1 text-danger">
                                    <strong><?php echo e($getLastLampStatus->time_off ?? 'N/A'); ?></strong></div>
                            </div>
                            <div class="col-md-4">
                                <div class="small mb-1">Batas jam untuk lampu menyala saat ini</div>
                                <div class="medium mb-1 text-success">
                                    <strong><?php echo e($getLastLampStatus->time_on ?? 'N/A'); ?></strong></div>
                            </div>
                        </div>
                        <div class="row" id="show">
                            <div class="form-group col-md-4">
                                <div class="small mb-1">Jam Mulai lampu menyala</div>
                                <input type="time" class="form-control" name="time_on" id="time_on">
                            </div>
                            <div class="form-group col-md-4">
                                <div class="small mb-1">Jam Akhir lampu mati</div>
                                <input type="time" class="form-control" name="time_off" id="time_off">
                            </div>
                        </div>
                    <?php endif; ?>
                    <div class="card-footer">
                        <div class="col-sm-12 mb-3">
                            <button type="submit" class="btn btn-primary float-right btn-sm"><i class="fas fa-edit"></i>
                                Ubah</button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
        <?php if(session('message')): ?>
            <div class="position-fixed top-0 right-0 p-3 w-25" style="z-index: 5; top: 0; right:0">
                <div id="liveToast" class="toast hide" role="alert" aria-live="assertive" aria-atomic="true"
                    data-delay="2000">
                    <div class="toast-header bg-success">
                        <strong class="mr-auto text-white">Tambah Device</strong>
                        <button type="button" class="ml-2 mb-1 close text-white" data-dismiss="toast"
                            aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="toast-body">
                        <?php echo e(session('message')); ?>

                    </div>
                </div>
            </div>
        <?php endif; ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('page-script'); ?>
    <script>
        function changeDevice() {
            var end = $("#device").val()
            window.history.replaceState(null, null, `?d=${end}`);
            location.reload();
        };
    </script>
    <?php if(isset($getLastLampStatus)): ?>
    <script>
        $(document).ready(function() {
            $('input[name=mode]').on('change', function() {
                var n = $(this).val();
                switch (n) {
                    case '1':
                        $('#status').html(`
                        <div class="col-md-4">
                            <div class="small mb-1">Batas jam untuk lampu mati saat ini</div>
                            <div class="medium mb-1 text-danger"><strong><?php echo e($getLastLampStatus->time_off ?? 'N/A'); ?></strong></div>
                        </div>
                        <div class="col-md-4">
                            <div class="small mb-1">Batas jam untuk lampu menyala saat ini</div>
                            <div class="medium mb-1 text-success"><strong><?php echo e($getLastLampStatus->time_on ?? 'N/A'); ?></strong></div>
                        </div>
                        `)
                        $('#show').html(`
                        <div class="form-group col-md-4">
                            <div class="small mb-1">Jam Mulai lampu menyala</div>
                            <input type="time" class="form-control" name="time_on" id="time_on">
                        </div>
                        <div class="form-group col-md-4">
                            <div class="small mb-1">Jam Akhir lampu mati</div>
                            <input type="time" class="form-control" name="time_off" id="time_off">
                        </div>
                        `);
                        break;
                    case '0':
                        $('#status').html(`
                        <div class="col-md-4">
                        <div class="small mb-1">Batas suhu untuk mati saat ini</div>
                        <div class="medium mb-1 text-danger"><strong><?php echo e($getLastLampStatus->suhu_mati ?? 'N/A'); ?></strong></div>
                    </div>
                    <div class="col-md-4">
                        <div class="small mb-1">Batas suhu nyala saat ini</div>
                        <div class="medium mb-1 text-success"><strong><?php echo e($getLastLampStatus->suhu_nyala ?? 'N/A'); ?></strong></div>
                    </div>
                        `)
                        $('#show').html(`
                        <div class="form-group col-md-4">
                        <div class="small mb-1">Batas suhu untuk lampu mati</div>
                        <div class="row justify-content-center align-items-center">
                            <div class="col-9">
                                <input type="range" class="custom-range w-100" min="25" max="35"
                                    value="<?php echo e($getLastLampStatus->suhu_mati); ?>" name="suhu_mati" id="suhu_mati"
                                    oninput="document.getElementById('label-suhu-mati').innerHTML = this.value">
                            </div>
                            <div class="col-3">
                                <span class="small mb-1 text-center" id="label-suhu-mati"><?php echo e($getLastLampStatus->suhu_mati); ?></span>
                                <span class="small mb-1">°C</span>
                            </div>
                        </div>
                    </div>
                    <div class="form-group col-md-4">
                        <div class="small mb-1">Batas suhu untuk lampu menyala</div>
                        <div class="row justify-content-center align-items-center">
                            <div class="col-9">
                                <input type="range" class="custom-range w-100" min="25" max="35"
                                    value="<?php echo e($getLastLampStatus->suhu_nyala); ?>" name="suhu_nyala" id="suhu_nyala"
                                    oninput="document.getElementById('label-suhu-nyala').innerHTML = this.value">
                            </div>
                            <div class="col-3">
                                <span class="small mb-1 text-center" id="label-suhu-nyala"><?php echo e($getLastLampStatus->suhu_nyala); ?></span>
                                <span class="small mb-1">°C</span>
                            </div>
                        </div>
                    </div>
                        `);
                        break;
                }
            });
        });
    </script>
    <?php endif; ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('template.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /media/nickyez/Data/#Kerjaan/kandang-ayam/Web/kandang-ayam/resources/views/pages/controls/lampu.blade.php ENDPATH**/ ?>