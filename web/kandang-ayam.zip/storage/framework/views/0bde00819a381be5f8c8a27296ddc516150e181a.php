<footer class="sticky-footer bg-white">
    <div class="container my-auto">
        <div class="copyright text-center my-auto">
            <span>Copyright &copy; Your Website 2021</span>
        </div>
    </div>
</footer><?php /**PATH /media/nickyez/Data/#Kerjaan/kandang-ayam/Web/kandang-ayam/resources/views/template/components/footer.blade.php ENDPATH**/ ?>