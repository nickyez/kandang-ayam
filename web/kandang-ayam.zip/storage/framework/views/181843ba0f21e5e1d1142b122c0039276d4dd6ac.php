<!-- Bootstrap core JavaScript-->
<script src="<?php echo e(asset("package/jquery/jquery.min.js")); ?>"></script>
<script src="<?php echo e(asset("package/bootstrap/js/bootstrap.bundle.min.js")); ?>"></script>

<!-- Core plugin JavaScript-->
<script src="<?php echo e(asset("package/jquery-easing/jquery.easing.min.js")); ?>"></script>

<!-- Custom scripts for all pages-->
<script src="<?php echo e(asset("js/sb-admin-2.min.js")); ?>"></script>

<!-- Page level plugins -->
<?php echo $__env->yieldPushContent('page-script'); ?>

<!-- Page level custom scripts -->
<?php echo $__env->yieldPushContent('data-script'); ?>
<?php /**PATH /media/nickyez/Data/#Kerjaan/kandang-ayam/Web/kandang-ayam/resources/views/template/components/script.blade.php ENDPATH**/ ?>