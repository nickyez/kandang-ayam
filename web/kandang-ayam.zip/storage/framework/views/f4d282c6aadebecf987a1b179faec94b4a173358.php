<?php $__env->startSection('title', 'Users'); ?>

<?php $__env->startPush('custom-style'); ?>
    <link href="<?php echo e(asset('package/datatables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <?php if(session('status')): ?>
        <div class="alert alert-warning alert-dismissible fade show" role="alert">
            <strong><?php echo e(session('status')); ?></strong>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>  
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <div class="d-sm-flex align-items-center justify-content-between">
                <h6 class="m-0 font-weight-bold text-primary">Data pengguna</h6>
                <a href="<?php echo e(Request::url() . '/create'); ?>" class="btn btn-primary btn-icon-split btn-sm">
                    <span class="icon text-white-50">
                        <i class="fas fa-plus"></i>
                    </span>
                    <span class="text">Tambah User</span>
                </a>
            </div>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>Nama</th>
                            <th>Email</th>
                            <th>Foto</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($user->name); ?></td>
                            <td><?php echo e($user->email); ?></td>
                            <td class="w-25"><img src="<?php echo e(asset($user->photos_url)); ?>" alt="<?php echo e($user->name); ?>" class="img-fluid"></td>
                            <td class="w-25">
                                <div class="row">
                                    <div class="col text-center">
                                        <a href="<?php echo e(Request::url() . '/' .$user->id.'/edit'); ?>" class="btn btn-sm btn-success">
                                            <i class="fa fa-edit"></i>
                                            <span class="text">Edit</span>
                                        </a>
                                    </div>
                                    <?php if($user->is_admin == 0): ?>
                                    <div class="col">
                                        <form action="<?php echo e(Request::url() . '/' .$user->id); ?>" method="post">
                                            <?php echo method_field('delete'); ?>
                                            <?php echo csrf_field(); ?>
                                            <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure?')">
                                                <i class="fa fa-trash"></i>
                                                <span class="text">Delete</span>
                                            </button>
                                        </form>
                                    </div>
                                    <?php endif; ?>
                                </div>
                                
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('page-script'); ?>
    <script src="<?php echo e(asset('package/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('package/datatables/dataTables.bootstrap4.min.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('data-script'); ?>
    <script src="<?php echo e(asset('js/demo/datatables-demo.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('template.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /media/nickyez/Data/#Kerjaan/kandang-ayam/Web/kandang-ayam/resources/views/pages/users/index.blade.php ENDPATH**/ ?>